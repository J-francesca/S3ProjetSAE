<?php

$tab_r;

echo "\n\n<ul>\n";
foreach ($tab_r as $r){
	
	$r->afficher();
	
}
echo "</ul>\n";
?>