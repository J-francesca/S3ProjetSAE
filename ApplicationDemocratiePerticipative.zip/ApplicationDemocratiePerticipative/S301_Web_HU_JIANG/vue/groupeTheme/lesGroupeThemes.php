<?php

$tab_gt;

echo "\n\n<ul>\n";
foreach ($tab_gt as $gt){
	
	$gt->afficher();
	
}
echo "</ul>\n";
?>