<?php

$tab_v;

echo "\n\n<ul>\n";
foreach ($tab_v as $v){
	
	$v->afficher();
	
}
echo "</ul>\n";
?>