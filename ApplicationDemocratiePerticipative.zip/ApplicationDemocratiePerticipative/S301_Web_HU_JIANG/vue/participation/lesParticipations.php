<?php

$tab_p;

echo "\n\n<ul>\n";
foreach ($tab_p as $p){
	
	$p->afficher();
	
}
echo "</ul>\n";
?>