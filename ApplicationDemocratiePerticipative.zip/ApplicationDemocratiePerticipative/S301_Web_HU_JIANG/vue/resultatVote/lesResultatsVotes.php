<?php

$tab_rv;

echo "\n\n<ul>\n";
foreach ($tab_rv as $rv){
	
	$rt->afficher();
	
}
echo "</ul>\n";
?>