<?php

$tab_g;

echo "\n\n<ul>\n";
foreach ($tab_g as $g){
	
	$g->afficher();
	
}
echo "</ul>\n";
?>