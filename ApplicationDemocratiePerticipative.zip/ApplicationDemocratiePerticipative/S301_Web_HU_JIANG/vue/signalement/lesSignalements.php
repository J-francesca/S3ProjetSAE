<?php

$tab_s;

echo "\n\n<ul>\n";
foreach ($tab_s as $s){
	
	$s->afficher();
	
}
echo "</ul>\n";
?>