<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="utf-8">
    <title><?php echo $titre; ?></title>

    <link rel="stylesheet" href="https://projets.iut-orsay.fr/saes3-shu/S301_Web_HU_JIANG/css/<?php echo $Style; ?>.css">

  </head>
  <body>
