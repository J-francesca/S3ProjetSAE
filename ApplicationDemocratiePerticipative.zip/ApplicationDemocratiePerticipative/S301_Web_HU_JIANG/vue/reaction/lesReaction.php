<?php

$tab_react;

echo "\n\n<ul>\n";
foreach ($tab_react as $react){
	
	$react->afficher();
	
}
echo "</ul>\n";
?>